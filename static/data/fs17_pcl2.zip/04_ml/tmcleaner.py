#!/usr/bin/env python3

"""
Implements a Naïve Bayes classifier for automatic translation memory cleaning.
"""

import csv

from sklearn.naive_bayes import GaussianNB

def main():
    classifier = TMCleaner('tm.tsv')
    print(classifier.is_valid_translation("The Fabulous Destiny of Amélie Poulain", "Le fabuleux destin d’Amélie Poulain"))

class TMCleaner:

    def __init__(self, training_data):
        self._training_data = self._read_training_data(training_data)
        self._feature_functions = [
            self._feature_ratio_chars,
            # add additional features here
        ]
        self._classifier = GaussianNB()
        self._train()

    @staticmethod
    def _read_training_data(filepath):
        with open(filepath, encoding="UTF-8") as tsvfile:
            reader = csv.reader(tsvfile, delimiter="\t")
            return [tuple(training_example) for training_example in reader]

    def _extract_feature_values(self, src, trg):
        return [f(src, trg) for f in self._feature_functions]

    def _train(self):
        pass #TODO

    def is_valid_translation(self, src, trg):
        """
        Returns `True` if, according to this classifier's model, @param src is a
        valid translation of @param trg; `False` otherwise.
        """
        pass #TODO

    # feature functions

    @staticmethod
    def _feature_ratio_chars(src, trg):
        try:
            return len(src) / len(trg)
        except ZeroDivisionError:
            return len(src)


if __name__ == "__main__":
    main()

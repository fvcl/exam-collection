#!/usr/bin/env python3


"""
Convert cell-phone contacts from vCard to TSV.
"""


import sys
import csv


def main():
    '''
    Run as script: Read vCard from STDIN, write TSV to STDOUT.
    '''
    contacts = parse_vcf(sys.stdin.buffer)
    writer = csv.writer(sys.stdout, delimiter='\t')
    writer.writerows(contacts)


def parse_vcf(lines):
    '''
    Extract contacts from a vCard file.

    Args:
        lines (iterable of bytes): lines of a vCard file.

    Returns:
        contacts (iterator over tuple(str, str)):
            name/number pairs
    '''
    # TODO


if __name__ == '__main__':
    main()

#!/usr/bin/env python3

"""
Splits a parallel corpus into a train, tune, and test set.
"""

import random

def main():
    split("corpus.en", "corpus.de", 1000, 2000)

def split(corpus_l1, corpus_l2, n_dev, n_test):
    """
    Splits a parallel corpus into a train, tune, and test set, with random
    assignment.

    All sets are written to file. File names are derived from @param corpus_l1
    and @param corpus_l2, with the following suffixes:
        * .train (e.g., `corpus.en.train`)
        * .dev   (e.g., `corpus.en.dev`)
        * .test  (e.g., `corpus.en.test`)

    @param corpus_l1 str (file name): segments of parallel corpus in language 1.
    @param corpus_l2 str (file name): segments of parallel corpus in language 2.
    @param n_dev int: the number of segments to be assigned to the dev set.
    @param n_test int: the number of segments to be assigned to the test set.
    """
    pass #TODO

if __name__ == "__main__":
    main()

#!/usr/bin/env python3


"""
TaggedSequence: A container for tagged text.
"""


import sys


class TaggedSequence:
    '''
    Two-layer sequence for text tokens along with tags.
    '''
    def __init__(self, tagged_sequence):
        '''
        Construct an instance from an iterable of <token, tag> pairs.
        '''
        # TODO

    def __iter__(self):
        '''
        Iterate over all <token, tag> pairs.

        Returns:
            iter(tuple(str, str)): each token with its tag
        '''
        # TODO

    def itertokens(self):
        '''
        Iterate over all text tokens.

        Returns:
            iter(str): all tokens
        '''
        # TODO

    def itertags(self):
        '''
        Iterate over all tags.

        Returns:
            iter(str): all tags
        '''
        # TODO

    def vertical(self, file=sys.stdout):
        '''
        Pretty-print to an open file in a tab-separated two-column format.

        Args:
            file (writable file-like for text): output stream
        '''
        # TODO

    def __getitem__(self, index_or_slice):
        '''
        Get one <token, tag> pair or a slice.

        Args:
            index_or_slice (int or slice): element selection

        Returns:
            > called with int index:
                tuple(str, str): selected <token, tag> pair
            > called with a slice:
                TaggedSequence: subsequence with selected elements
        '''
        # TODO

    def find(self, tag):
        '''
        Extract all tokens that have the given tag.

        Args:
            tag (str): the tag of the targeted tokens

        Returns:
            iter(str): all tokens matching `tag`
        '''
        # TODO

    def find_subsequences(self, tags):
        '''
        Extract all token subsequences that match `tags`.

        Args:
            tags (iterable of str): the tags of the targeted token sequences

        Returns:
            iter(list(str)): all sequences of tokens that are tagged with `tags`
        '''
        # TODO (optional)

    def __add__(self, other):
        '''
        Concatenate this TaggedSequence with another tagged sequence.

        Args:
            other (TaggedSequence or iterable of tuple(str, str)):
                the tagged sequence to be added

        Returns:
            TaggedSequence: the new concatenated sequence
        '''
        # TODO (optional)

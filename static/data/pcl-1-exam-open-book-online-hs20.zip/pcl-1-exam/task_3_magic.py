#!/usr/bin/python3
# -*- coding: utf-8 -*-

# Clair Chaos wrote a program in order to test whether you have the magical power to correctly guess the number that a dice rolls.
# Actually, the program lets you guess infinitely until you predict the correct number.
# But your chances are always 1/6 to predict the rolled number.
# Every non-integer is silently ignored and the user is prompted
# So, everyone is a bit of a magician in the end...
# Unfortuately, Clair Chaos mixed up all lines and lost the indentation. Can you please help her to reconstruct the program.
# IMPORTANT: Please write a short comment BEFORE EACH LINE that explains what the next line does.

### YOUR Python comments and code start here ###


r = random.sample(dice, 1)
g = int(input("Guess which number the dice rolled: "))
print(f"Amazing! The dice indeed rolled a {g}! You are a 🧙‍! ")
if r[0] == g:
while True:
except Exception:
print("You know nothing, Jon Snow...")
break
else:
dice = [1, 2, 3, 4, 5, 6]
try:
import random
pass

### YOUR Python comments and code end here ###

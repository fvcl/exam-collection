#!/usr/bin/env python3
# coding: utf8

"""
Inventory: container for available books in the inventory.

Reviews: container for a structured representation of book reviews.

ReviewsManager: container for reviews management of available books.
"""
from pathlib import Path
from typing import List, Tuple, Dict
from collections import defaultdict

import csv

INVENTORY_FILE = Path(__file__).parent / 'comic_inventory.tsv'
REVIEWS_FILE = Path(__file__).parent / 'reviews_data.json'


class Inventory:
    """Inventory of available books."""
    def __init__(self, inventory_file: str):
        self._id2title, self._title2id = self._load(inventory_file)
        self.titles = list(self._id2title.values())

    @staticmethod
    def _load(inventory_file: str) -> Tuple[Dict[int, str], Dict[str, int]]:
        """Loads an inventory from a tsv file and returns lookup tables"""
        with open(inventory_file) as inventory:
            reader = csv.DictReader(inventory, delimiter='\t')
            id2title = {int(entry["book_id"]): entry["title"] for entry in reader}
            title2id = {v: k for k, v in id2title.items()}
            return id2title, title2id

    def title_to_id(self, title: str) -> int:
        """Returns the corresponding id for a given title."""
        if title not in self._title2id:
            raise KeyError("title '{0}' not found".format(title))
        return self._title2id[title]

    def id_to_title(self, book_id: int) -> str:
        """Returns the corresponding title for a given book_id."""
        if book_id not in self._id2title:
            raise KeyError("id '{0}' not found".format(book_id))
        return self.id_to_title[book_id]

    def __contains__(self, title: str) -> bool:
        """Checks whether a book is in the inventory."""
        return title in self.titles

    def __len__(self) -> int:
        """Gets total of books in the inventory"""
        return len(self.titles)


class Reviews:
    """Structured representation of book reviews split between positive and negative."""
    def __init__(self, reviews_file: str):
        ... # TODO
    
    @staticmethod
    def _load(reviews_file: str) -> Dict[int, Dict[List[str], List[str]]]:
        """
        Loads book reviews from a json file and returns a dictionary with the following structure:
            reviews = {
                        book_id_1: {
                            "pos": [positive_review_1, ..., positive_review_n],
                            "neg": [negative_review_1, ..., negative_review_k],
                        },
                        ...
                        book_id_m: {
                            "pos": [...],
                            "neg": [...]
                        }
                    }
            where:
                - "pos" contains the positive reviews (i.e. rating is 4 or 5)
                - "neg" contains the negative reviews (i.e. rating is 1 or 2)
        """
        reviews = defaultdict(lambda: defaultdict(list))
        ... # TODO

    def pos_neg_sample(self, book_id) -> Tuple[str, str]:
        """Returns a positive and a negative review for a given book_id. Both reviews are randomly selected."""
        ... # TODO


class ReviewsManager:
    """Reviews manager of the available books"""
    def __init__(self, inventory_file: str, reviews_file: str):
        ... # TODO

    def available_books(self) -> List[str]:
        """Returns the available books in the inventory"""
        ... # TODO

    def print_balanced_review(self, title: str):
        """Prints a randomly selected positive and negative review for a given book title."""
        ... # TODO

# Exam
*Programming Techniques in Computational Linguistics II, FS 2022*  
*Lecturer: Laura Mascarell*

***

"I hereby confirm that this assessment in no way violates the Code of Honor for official assessments of the Faculty of Arts and Social Sciences of the University of Zurich."

Name of Student:

Immatriculation number:

Date:

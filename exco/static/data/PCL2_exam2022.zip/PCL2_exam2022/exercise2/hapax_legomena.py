#!/usr/bin/env python3
# coding: utf8

"""
Displays the n sentences that have the maximum number of Hapax Legomena in the input file.
A word is hapax legomenon (plural hapax legomena) if it appears only once in the full document.
"""

import argparse
import nltk

from typing import List, Dict
from collections import Counter


def parse_arguments():
    def check_positive_int(value: str) -> int:
        """Checks if value is a positive integer"""
        int_value = int(value)
        if int_value <= 0:
            return argparse.ArgumentTypeError("%s is an invalid positive int value" % value)

        return int_value

    parser = argparse.ArgumentParser(description='top n sentences with Hapax Legomena')

    parser.add_argument("-i", '--input',
                        type=str,
                        help="File path)",
                        required=True)

    parser.add_argument('-n', '--num',
                        type=check_positive_int,
                        help="Total of top sentences with Hapax Legomena to display",
                        required=True)
    return parser.parse_args()


def get_tokens(text: str) -> List[str]:
    """Tokenizes text."""
    tokenizer = nltk.tokenize.TreebankWordTokenizer()
    tokens = tokenizer.tokenize(text.lower())
    return tokens


def get_hapax_legomena(text: str) -> List[str]:
    """Gets all hapax legomena from text."""
    token_count = Counter(text)
    hapax_legomena = dict(filter(lambda item: item[1] > 0, token_count.items()))
    return list(hapax_legomena.keys())


def update_hapax_legomena_sent(sentence: str, hapax_legomena: List[str], hapax_legomena_sent: Dict[str, int]):
    """Updates hapax_legomena_sent with the new sentence and its hapax legomena count."""
    tokens = get_tokens(sentence)
    count = sum(map(lambda token: token in hapax_legomena, tokens))

    if count > 0:
        hapax_legomena_sent[sentence] = count


def main(args):
    with open(args.input) as f:
        text = f.read()
        hapax_legomena = get_hapax_legomena(text)

    hapax_legomena_sent = defaultdict(int)

    for sentence in text.split("\n"):
        update_hapax_legomena_sent(sentence, hapax_legomena, hapax_legomena_sent)

    for (sentence, value) in hapax_legomena_sent[:args.num]:
        print(f"{value}\t{sentence}")


if __name__ == '__main__':
    parse_args = parse_arguments()
    main(parse_args)
